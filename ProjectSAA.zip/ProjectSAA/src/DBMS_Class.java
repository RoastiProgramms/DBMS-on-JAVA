import hashset.HashSetCustom;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class DBMS_Class implements DBMS_Interface{

    private final static String path="C:\\Users\\RoastiSpielt\\Desktop\\SAA\\";
    public static String databaseName = "";

    @Override
    public boolean listTables(String dbName) {
        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();

        if (listOfFiles == null) {
            System.out.println("No tables exist!");
            return false;
        } else {
            for (File file : listOfFiles) {
                if (file.isFile() && file.getName().endsWith('_'+dbName+".xml")) {
                    String fileName = file.getName();
                    System.out.println(fileName.substring(0, fileName.length() - 5-dbName.length()));
                }
            }
            return true;
        }
    }
    @Override
    public boolean createDatabase(String dbName) {
        try {
        databaseName = dbName;
        String directory = path + dbName + ".xml";
        Element tables=new Element("tables");
        Document doc=new Document();
        XMLOutputter xmlOut= new XMLOutputter();
        doc.setRootElement(tables);
        xmlOut.setFormat(Format.getPrettyFormat());
        xmlOut.output(doc,new FileWriter(directory));
        System.out.println("Database "+dbName+" created");
        return true;
        } catch (IOException e) {
            System.out.println("Error in file");
            return false;
        }
    }

    @Override
    public boolean createTable(String tableName, ArrayList<String> types, ArrayList<String> values) {
        if (updateDatabaseFile( tableName ,values,types) ){
            try {
                String directory = path + tableName + "_" + databaseName +".xml";
                Element table = new Element( tableName );
                Document doc = new Document();
                doc.setRootElement(table);

                XMLOutputter xmlOutput = new XMLOutputter();

                xmlOutput.setFormat(Format.getPrettyFormat());
                xmlOutput.output(doc, new FileWriter( directory ));
                System.out.println("Table "+tableName+" created");
                return true;
            } catch (IOException io) {
                System.out.println("File ERROR!!");
                return false;
            }

        }//end if .
		else{
            System.out.println("table exists!!");
            return false;
        }
    }

    @Override
    public boolean insertIntoTable(String tableName, String[] corresValue, String[] value) {
        if( checkTableExist(tableName) ){

            try {

                HashSetCustom set=new HashSetCustom<String>();
                for( int i = 0 ;i < corresValue.length ;i++){
                    set.add( corresValue[i] );
                    String t = getType( tableName ,corresValue[i] );
                    if( t == null ){
                        System.out.println("The attribute " + corresValue[i] + "does not exist.");
                        return false;
                    }

                }


                String dir = path + tableName +"_" + databaseName + ".xml";

                SAXBuilder builder = new SAXBuilder();
                File xmlFile = new File( dir );

                Document doc = builder.build(xmlFile);
                Element rootNode = doc.getRootElement();

                Element row = new Element("row");
                for( int i = 0 ;i < corresValue.length ;i++){
                    row.addContent(new Element( corresValue[i] ).setText( value[i] ));
                }
                List list = getList(tableName);
                for( int i = 0 ;i < list.size() ;i++){
                    Element node = (Element) list.get(i);
                    if( !set.contains( node.getText() ) ){
                        row.addContent(new Element( node.getText() +"" ).setText( "" ));
                    }
                }

                rootNode.addContent(row);

                XMLOutputter xmlOutput = new XMLOutputter();

                xmlOutput.setFormat(Format.getPrettyFormat());
                xmlOutput.output(doc, new FileWriter(dir) );
                System.out.println("Information inserted in : "+tableName);
                return true;
            } catch (IOException io) {

                System.out.println("File Error.");
                return false;
            } catch (JDOMException e) {
                System.out.println("JDOM Exception.");
                return false;
            }catch(Exception e){
                System.out.println("You have to stick to the type.");
                return false;
            }
        }
        else{
            System.out.println("table does not exist ");
            return false;
        }

    }

    private List getList(String tableName) {
        try {
            String dir = path + databaseName + ".xml";
            SAXBuilder builder = new SAXBuilder();
            File xmlFile = new File( dir );
            Document doc = builder.build(xmlFile);

            Element rootNode = doc.getRootElement();

            Element tableN = null;
            List list =  rootNode.getChildren();
            for( int i = 0 ;i < list.size() ;i++){
                Element node = (Element) list.get(i);
                String typeShape = node.getAttributeValue("name");
                if( typeShape.equals(tableName) ){
                    tableN = node.clone();
                }
            }


            Element rowSpecial = tableN.getChild("rowSpecial");

            List list2 = rowSpecial.getChildren();

            return list2;
        } catch (JDOMException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    @Override
    public ArrayList<String>[] selectFromTable(String tableName, String[] corresValue, String[] condition) {
        if( checkTableExist(tableName) ){

            try {

                String dir = path + tableName +"_" + databaseName + ".xml";
                SAXBuilder builder = new SAXBuilder();
                File xmlFile = new File( dir );

                Document doc = builder.build(xmlFile);
                Element rootNode = doc.getRootElement();

                if( corresValue[0].equals( "*" ) ){
                    List test = getList(tableName);
                    corresValue = new String[ test.size() ];

                    for( int i = 0 ;i < test.size() ;i++){
                        Element node = (Element) test.get(i);
                        corresValue[i] = node.getText();
                    }

                }
                String t = getType( tableName ,condition[0] );
                if( t.equals("String") && !condition[1].equals("=") ){
                    System.out.println("Not a valid Condition.");
                }else if( t.equals("int") ){
                    int x = Integer.parseInt( condition[2] );
                }else if (t.equals("double")){
                    double x = Double.parseDouble( condition[2] );
                }

                List list = rootNode.getChildren( "row" );

                ArrayList<String>[] wanted;
                wanted = new ArrayList[ corresValue.length ];
                for (int i = 0; i < wanted.length; i++) {
                    wanted[i] = new ArrayList<String>();
                    wanted[i].add( corresValue[i] );
                }

                boolean check = true;
                for( int i = 0 ;i < corresValue.length ;i++){
                    if( !list.contains( corresValue[i] ) ){
                        check = false;
                    }
                }

                if(!check){
                    return null;
                }

                for( int i = 0 ;i < list.size() ;i++){
                    Element node = (Element) list.get(i);
                    String current = node.getChildText( condition[0] );
                    if( checkCondition( condition ,t,current ) ){
                        for( int j = 0 ;j < corresValue.length ;j++){
                            wanted[j].add( node.getChildText(corresValue[j]) );

                        }

                    }

                }
                System.out.println("Here is the information:");
                System.out.println();
                return wanted;
            } catch (IOException io) {

                System.out.println("File exception.");
                return null;
            } catch (JDOMException e) {

                System.out.println("JDOM Exception.");
                return null;
            }catch( Exception e){
                System.out.println( "You have to stick to the type." );
                return null;
            }


        }
        else{
            System.out.println("Table does not Exist.");
            return null;
        }
    }

    @Override
    public boolean deleteFromTable(String tableName, String[] arrayCondition) {
        if (checkTableExist(tableName)) {
            if(arrayCondition.length < 2) {
                System.out.println("Incomplete delete statement.");
                return false;
            }
            try {
                String dir = path + tableName + "_" + databaseName + ".xml";
                SAXBuilder builder = new SAXBuilder();
                File xmlFile = new File(dir);
                Document doc = builder.build(xmlFile);
                Element rootNode = doc.getRootElement();
                List<Element> rows = rootNode.getChildren("row");
                int count = 0;
                for (Element row : rows) {
                    List<Element> columns = row.getChildren();
                    for (Element column : columns) {
                        if (column.getName().equals(arrayCondition[0]) && column.getText().equals(arrayCondition[2])) {
                            row.detach();
                            count++;
                            break;
                        }
                    }
                }
                XMLOutputter xmlOutput = new XMLOutputter();
                xmlOutput.setFormat(Format.getPrettyFormat());
                xmlOutput.output(doc, new FileWriter(dir));
                System.out.println(count + " row(s) deleted from " + tableName);
                return true;
            } catch (IOException io) {
                System.out.println("File Error.");
                return false;
            } catch (JDOMException e) {
                System.out.println("JDOM Exception.");
                return false;
            }
        } else {
            System.out.println("Table " + tableName + " does not exist.");
            return false;
        }
    }

    @Override
    public boolean updateTable(String tableName, String[] corresValue, String[] values, String[] condition) {
        if( checkTableExist(tableName) ){

            try {
                String dir = path + tableName +"_" + databaseName + ".xml";

                SAXBuilder builder = new SAXBuilder();
                File xmlFile = new File( dir );

                Document doc = builder.build(xmlFile);
                Element rootNode = doc.getRootElement();

                String t = getType( tableName,condition[0] );

                if( t.equals("String") && !condition[1].equals("=") ){
                }else if( t.equals("int") ){
                    int x = Integer.parseInt( condition[2] );
                }else if (t.equals("double")){
                    double x = Double.parseDouble( condition[2] );
                }

                List list = rootNode.getChildren();
                for( int i = 0 ;i < list.size() ;i++){
                    Element node = (Element) list.get(i);
                    String current = node.getChildText( condition[0] );
                    if( checkCondition( condition ,t ,current ) ){
                        for( int j = 0 ; j < corresValue.length ;j++){
                            node.getChild(corresValue[j]).setText(values[j]);
                        }
                    }
                }

                XMLOutputter xmlOutput = new XMLOutputter();

                xmlOutput.setFormat(Format.getPrettyFormat());
                xmlOutput.output(doc, new FileWriter( dir ));
                System.out.println("Table "+tableName+" updated");
                return true;
            } catch (IOException io) {

                System.out.println("File Error.");
                return false;
            } catch (JDOMException e) {
                System.out.println("JDOM Exception.");
                return false;
            }catch(Exception e){
                System.out.println("here");
                return false;
            }
        }
        else{
            System.out.println("Table "+tableName+" does not exist");
            return false;
        }
    }

    @Override
    public boolean useDatabase(String dbName) {
        String dir = path + dbName + ".xml";
        databaseName=dbName;
        try {
            FileReader fr = new FileReader(dir);
        } catch (FileNotFoundException e) {
            System.out.println("Database Not Found.");
            return false;
        }
        System.out.println("Using Database: "+dbName+" successfully");
        return true;
    }
    public boolean updateDatabaseFile(String tableName , ArrayList<String> values, ArrayList<String> types) {
        try {

            if (checkTableExist(tableName)) {
                System.out.println("Table already Exists!!");
                return false;
            }

            SAXBuilder builder = new SAXBuilder();

            File xmlFile = new File(path + databaseName + ".xml");

            Document doc = (Document) builder.build(xmlFile);
            Element rootNode = doc.getRootElement();
            Element tableN = new Element("table").setAttribute("name", tableName);
            rootNode.addContent(tableN);


            Element row = new Element("rowSpecial").setAttribute("num", values.size() + "");
            for (int i = 0; i < types.size(); i++) {
                row.addContent(new Element(values.get(i)).setText(values.get(i)).setAttribute("type", types.get(i)));
            }
            tableN.addContent(row);

            XMLOutputter xmlOutput = new XMLOutputter();

            xmlOutput.setFormat(Format.getPrettyFormat());
            xmlOutput.output(doc, new FileWriter(path + databaseName + ".xml"));

					System.out.println("File updated!");
            return true;
        } catch (IOException io) {

            System.out.println("File not found!!");
            return false;
        } catch (JDOMException e) {

            System.out.println("JDOM Exception!!");
            return false;
        }
    }
        public boolean checkTableExist (String tableName ){

            try {
                SAXBuilder builder = new SAXBuilder();
                File xmlFile = new File(path + databaseName + ".xml");
                Document doc = builder.build(xmlFile);
                Element rootNode = doc.getRootElement();

                List list = rootNode.getChildren();
                for (int i = 0; i < list.size(); i++) {
                    Element node = (Element) list.get(i);
                    String typeShape = node.getAttributeValue("name");
                    if (typeShape.equals(tableName)) {
                        return true;
                    }
                }

                return false;
            } catch (IOException io) {
                io.printStackTrace();
                return true;
            } catch (JDOMException e) {
                e.printStackTrace();
                return true;
            }
        }
    public String getType(String tableName, String value) {
        try {
            String dir=path+databaseName+".xml";
            SAXBuilder builder = new SAXBuilder();
            File xmlFile = new File(dir);
            Document doc = builder.build(xmlFile);
            for (Element column : doc.getRootElement().getChildren().get(0).getChildren().get(0).getChildren()) {
                if (column.getAttributes().get(0).getValue().equals(value)) {
                    return column.getName();
                }
            }
        } catch (IOException | JDOMException e) {
            e.printStackTrace();
        }
        return null;
    }
    public boolean checkCondition( String[] condition ,String type ,String current){

        try{

            if( type.equals("int") ){
                int x = Integer.parseInt( current );
                int y = Integer.parseInt( condition[2] );

                if( condition[1].equals(">") && x > y ){
                    return true;
                }
                else if( condition[1].equals("<") && x < y ){
                    return true;
                }
                else if( condition[1].equals("=") && x == y ){
                    return true;
                }
            }
            else if( type.equals("double") ){
                double x = Double.parseDouble( current );
                double y = Double.parseDouble( condition[2] );

                if( condition[1].equals(">") && x > y ){
                    return true;
                }
                else if( condition[1].equals("<") && x < y ){
                    return true;
                }
                else if( condition[1].equals("=") && x == y ){
                    return true;
                }
            }
            else if( type.equals("String") ){
                if( current.equals(condition[2]) ){
                    return true;
                }
            }

            return false;
        }catch( Exception e ){
            System.out.println("You have to Stick to the type.");
            return false;
        }

    }

}
