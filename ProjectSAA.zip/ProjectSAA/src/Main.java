import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {
        Scanner in  = new Scanner(System.in);
        Parser Q = new Parser();
        boolean database = false;
        System.out.println("please choose one of these two options: ");
        System.out.println("1- Create Database");
        System.out.println("2- Use Database");
        System.out.println("3- List Tables from Database");
        System.out.println("Or you can quit the program if you type 'exit'");
        while(true)
        {
            System.out.println("please enter the query: ");
            String query = in.nextLine();
            if (query.equalsIgnoreCase("exit")) {
                System.out.println("Exiting program...");
                break;
            }
            boolean catchy = false; String w1 = "",w2 = "",w3 = "";
            if(!database)
            {
                StringTokenizer st =  new StringTokenizer(query);
                try{
                    w1 = st.nextToken(); w2 = st.nextToken(); w3 = st.nextToken();
                }
                catch(Exception e){catchy = true;}
                while(catchy || ((!w1.equalsIgnoreCase("CREATE") && !w2.equalsIgnoreCase("DATABASE"))
                        && (!w1.equalsIgnoreCase("USE") && !w2.equalsIgnoreCase("DATABASE"))
                        && (!w1.equalsIgnoreCase("LIST") && !w2.equalsIgnoreCase("TABLES"))))
                {
                    catchy = false;
                    System.out.println("wrong entry, Please enter the query: ");
                    query = in.nextLine();
                    st =  new StringTokenizer(query);
                    try{
                        w1 = st.nextToken(); w2 = st.nextToken(); w3 = st.nextToken();
                    }
                    catch(Exception e){catchy = true;}
                }
                database = true;
            }
           while(!Q.splitAll(query))
           {
               System.out.println("please enter the query: ");
               query = in.nextLine();
           }
        }
    }
}
