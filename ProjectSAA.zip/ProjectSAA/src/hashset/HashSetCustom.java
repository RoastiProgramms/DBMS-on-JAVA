package hashset;

import java.util.ArrayList;

public class HashSetCustom<String> {
    private ArrayList<String >[] buckets;
    private int size;

    public HashSetCustom() {
        this.buckets = new ArrayList[5000];
        for (int i = 0; i < buckets.length; i++) {
            buckets[i] = new ArrayList<>();
        }
        this.size = 0;
    }

    public boolean contains(Object o) {
        int index = (o.hashCode() % buckets.length + buckets.length) % buckets.length;
        ArrayList<String> bucket = buckets[index];
        for (String item : bucket) {
            if (item.equals(o)) {
                return true;
            }
        }
        return false;
    }

    public boolean add(String t) {
        int index = (t.hashCode() % buckets.length + buckets.length) % buckets.length;
        ArrayList<String> bucket = buckets[index];
        if (!bucket.contains(t)) {
            bucket.add(t);
            size++;
            return true;
        }
        return false;
    }

    public boolean remove(Object o) {
        int index = (o.hashCode() % buckets.length + buckets.length) % buckets.length;
        ArrayList<String> bucket = buckets[index];
        if (bucket.remove(o)) {
            size--;
            return true;
        }
        return false;
    }
}
